import type { Metadata } from "next";
import ApplicationPageShell from "@/components/applications/ApplicationPageShell";
import { buildMetadata } from "@/lib/seo";

export const dynamic = "force-dynamic";

export function generateMetadata(): Promise<Metadata> {
  return buildMetadata("/education/admission");
}

export default async function StudentAdmissionPage({
  searchParams,
}: {
  searchParams: Promise<{ course?: string }>;
}) {
  const { course } = await searchParams;
  return <ApplicationPageShell kind="admission" initialProgram={course} />;
}
