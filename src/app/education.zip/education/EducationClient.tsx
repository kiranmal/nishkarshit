"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import {
  GraduationCap,
  Briefcase,
  Scale,
  Cpu,
  HeartPulse,
  Cloud,
  ChevronDown,
} from "lucide-react";
import Header from "@/components/Header";
import TopBar from "@/components/TopBar";
import Footer from "@/components/Footer";
import FloatingButtons from "@/components/FloatingButtons";
import { StatCounter, StaticStat } from "@/components/StatCounter";
import EducationTabs from "@/components/education/EducationTabs";
import EducationBreadcrumb from "@/components/education/EducationBreadcrumb";
import CourseCard from "@/components/education/CourseCard";
import ApplicationForm from "@/components/applications/ApplicationForm";

const tabs = [
  { id: "overview", label: "Overview" },
  { id: "internship", label: "Internship" },
  { id: "admission", label: "Admission" },
  { id: "partners", label: "Our Partners" },
  { id: "events", label: "Events & Programs" },
];

const courses = [
  {
    icon: Cpu,
    category: "ENGINEERING & TECH",
    badge: "100% ONLINE",
    title: "B.Tech / M.Tech",
    detail:
      "Engineering degrees in Computer Science, AI & ML, Cloud Computing, and Data Science — fully accredited with industry labs.",
    tags: [
      "Live Virtual Labs",
      "AI & Cloud Specializations",
      "Industry Mentorship",
    ],
    duration: "2 – 4 Years",
  },
  {
    icon: Briefcase,
    category: "BUSINESS & MANAGEMENT",
    badge: "GLOBAL DEGREE",
    title: "MBA / PGDM",
    detail:
      "India's highest-ROI management degrees from NMIMS, Manipal, and Amity. Specializations in Marketing, Finance, HR & Analytics.",
    tags: [
      "Harvard Case Studies",
      "Executive Networking",
      "C-Suite Mentorship",
    ],
    duration: "2 Years",
  },
  {
    icon: Scale,
    category: "CORPORATE LAW & ETHICS",
    badge: "BAR COUNCIL ALIGNED",
    title: "LLB / Law Programs",
    detail:
      "Pursue premier legal education online from OP Jindal and leading law schools for careers in corporate compliance and cyber jurisprudence.",
    tags: ["Moot Court Simulators", "Corporate Compliance", "Cyber Law Focus"],
    duration: "3 – 5 Years",
  },
  {
    icon: GraduationCap,
    category: "APPLIED COMPUTER SCIENCE",
    badge: "PROJECT-DRIVEN",
    title: "BCA / MCA",
    detail:
      "Computer applications degrees focused on programming, systems design and modern software development practices.",
    tags: ["Live Coding Labs", "Capstone Projects", "Placement Prep"],
    duration: "3 Years",
  },
  {
    icon: HeartPulse,
    category: "HEALTHCARE & PHARMA",
    badge: "ACCREDITED",
    title: "Health Sciences",
    detail:
      "Accredited healthcare and pharma programs built for clinical and allied-health careers, with hands-on lab components.",
    tags: ["Clinical Practicals", "Pharma Compliance", "Accredited Faculty"],
    duration: "2 – 4 Years",
  },
  {
    icon: Cloud,
    category: "SHORT-TERM UPSKILLING",
    badge: "SELF-PACED",
    title: "IT & Cloud Certifications",
    detail:
      "Short, self-paced certification tracks in cloud platforms, DevOps and cybersecurity — built to get you job-ready fast.",
    tags: ["Self-Paced", "Industry Certification", "No Prior Degree Needed"],
    duration: "1 – 6 Months",
  },
];

const journeySteps = [
  {
    title: "Explore Programs",
    desc: "Browse courses across our 30+ university partners.",
  },
  {
    title: "Apply Online",
    desc: "Submit your application digitally — no paperwork runaround.",
  },
  {
    title: "Get Counselled",
    desc: "A dedicated counsellor walks you through the right fit.",
  },
  {
    title: "Enroll & Learn",
    desc: "Start learning with full placement and internship support.",
  },
];

const highlights = [
  "Flexible & Accessible for All",
  "Affordable Fee Structures",
  "Flexible Duration & Batch Options",
  "Industry-Aligned Curriculum",
];

const internshipDeliverables = [
  "Real client projects, not busywork",
  "A dedicated mentor throughout",
  "A certificate + portfolio piece at the end",
  "Direct referral into our hiring pipeline",
];

const admissionSteps = [
  {
    title: "Apply Online",
    desc: "Fill out the digital application form in minutes.",
  },
  {
    title: "Document Verification",
    desc: "Upload documents — verified within 24-72 hours.",
  },
  {
    title: "Counselling Call",
    desc: "Get matched to the right program for your goals.",
  },
  {
    title: "Confirm & Enroll",
    desc: "Secure your seat and get your student portal access.",
  },
];

const upcomingEvents = [
  {
    title: "Career Fair — IT & Banking",
    date: "Every quarter",
    color: "#17b6e8",
  },
  {
    title: "Free Skill-Development Webinar",
    date: "Monthly",
    color: "#7c3aed",
  },
  {
    title: "University Partner Open Day",
    date: "Bi-monthly",
    color: "#22c55e",
  },
];

export default function EducationClient() {
  const [active, setActive] = useState("overview");
  const [openCourse, setOpenCourse] = useState<number | null>(null);
  // Student Admission form opens inside the Admission tab (no page change).
  const [showForm, setShowForm] = useState(false);
  const [formCourse, setFormCourse] = useState<string | undefined>();

  function openAdmissionForm(course?: string) {
    setFormCourse(course);
    setShowForm(true);
    setActive("admission");
    requestAnimationFrame(() =>
      document
        .getElementById("admission-form")
        ?.scrollIntoView({ behavior: "smooth", block: "start" }),
    );
  }

  // Let nav links like /education#admission open the matching tab.
  useEffect(() => {
    const sync = () => {
      const id = window.location.hash.replace("#", "");
      if (id === "student-admission") {
        setActive("admission");
        setShowForm(true);
      } else if (tabs.some((t) => t.id === id)) setActive(id);
    };
    sync();
    window.addEventListener("hashchange", sync);
    return () => window.removeEventListener("hashchange", sync);
  }, []);

  return (
    <>
      <TopBar />
      <Header />
      <main className="flex-1 bg-[#050b16]">
        {/* Cosmic hero */}
        <section
          className="relative py-20 overflow-hidden"
          style={{
            backgroundColor: "#050b16",
            backgroundImage:
              "linear-gradient(rgba(0,160,227,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(0,160,227,0.06) 1px, transparent 1px)",
            backgroundSize: "36px 36px",
          }}
        >
          <div className="pointer-events-none absolute -top-32 left-1/3 w-[500px] h-[500px] rounded-full bg-brand-cyan/10 blur-[120px]" />
          <div className="pointer-events-none absolute -bottom-32 right-1/4 w-[400px] h-[400px] rounded-full bg-purple-600/10 blur-[120px]" />

          <div className="relative max-w-[1440px] mx-auto px-6 md:px-16 text-center">
            <span className="inline-block text-xs font-bold uppercase tracking-wide text-brand-cyan bg-brand-cyan/10 px-4 py-1.5 rounded-full mb-5">
              Empowering India&apos;s Youth Through IT
            </span>
            <motion.h1
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-white text-3xl md:text-5xl font-bold max-w-3xl mx-auto leading-tight"
              style={{ fontFamily: "var(--font-poppins)" }}
            >
              Smart Education for a Smarter Future
            </motion.h1>
            <p className="text-white/60 max-w-xl mx-auto mt-5">
              Indian universities, offering fully accredited online degree
              programs and skill certifications.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4 mt-8">
              <Link
                href="#courses"
                className="rounded-full bg-brand-cyan text-[#050b16] text-sm font-bold px-7 py-3 hover:bg-white transition-colors"
              >
                Explore Programs
              </Link>
              <Link
                href="#highlights"
                className="rounded-full border border-white/20 text-white text-sm font-semibold px-7 py-3 hover:bg-white/10 transition-colors"
              >
                View Highlights
              </Link>
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="bg-[#0a1526] py-14 border-y border-white/5">
          <div className="max-w-[1440px] mx-auto px-6 md:px-16 grid grid-cols-2 md:grid-cols-4 gap-10">
            <StatCounter
              value={30}
              suffix="+"
              label="University Partners"
              color="#17b6e8"
            />
            <StatCounter
              value={100}
              suffix="+"
              label="Programs Available"
              color="#22c55e"
            />
            <StatCounter
              value={100}
              suffix="%"
              label="Placement Assistance"
              color="#eab308"
            />
            <StaticStat text="UGC" label="Approved Degrees" color="#17b6e8" />
          </div>
        </section>

        {/* Tabs */}
        <section className="border-b border-white/10 sticky top-[73px] bg-[#050b16] z-30">
          <div className="max-w-[1440px] mx-auto px-6 md:px-16 flex gap-8 overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActive(tab.id)}
                className={`relative py-4 text-sm font-semibold tracking-wide uppercase whitespace-nowrap transition-colors ${
                  active === tab.id
                    ? "text-brand-cyan"
                    : "text-white/40 hover:text-white/70"
                }`}
              >
                {tab.label}
                {active === tab.id && (
                  <motion.div
                    layoutId="edu-tab-underline"
                    className="absolute left-0 right-0 -bottom-px h-0.5 bg-brand-cyan"
                  />
                )}
              </button>
            ))}
          </div>
        </section>

        {/* Tab content */}
        <section className="max-w-[1440px] mx-auto px-6 md:px-16 py-16 min-h-[400px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={active}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -14 }}
              transition={{ duration: 0.35 }}
            >
              {active === "overview" && (
                <div className="space-y-16">
                  <div>
                    <h2
                      className="text-2xl md:text-3xl font-bold text-white mb-4"
                      style={{ fontFamily: "var(--font-poppins)" }}
                    >
                      Education, Reimagined
                    </h2>
                    <p className="text-white/60 max-w-2xl leading-relaxed">
                      We partner with UGC-approved Indian universities to offer
                      fully accredited online degree programs and skill
                      certifications, giving learners flexible access to quality
                      higher education.
                    </p>
                  </div>

                  {/* Courses — clickable cards */}
                  <div id="courses">
                    <h3 className="text-xl font-bold text-white mb-2">
                      Courses for Every Career Goal
                    </h3>
                    <p className="text-white/40 text-sm mb-6">
                      Tap a program to see what&apos;s inside.
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {courses.map((c, i) => {
                        const Icon = c.icon;
                        const isOpen = openCourse === i;
                        return (
                          <div
                            key={c.title}
                            className="rounded-2xl border border-white/10 bg-white/5 overflow-hidden"
                          >
                            <button
                              onClick={() => setOpenCourse(isOpen ? null : i)}
                              className="w-full flex items-center justify-between gap-4 p-5 text-left"
                            >
                              <div className="flex items-center gap-4">
                                <div className="w-11 h-11 rounded-xl bg-brand-cyan/15 flex items-center justify-center shrink-0">
                                  <Icon size={20} className="text-brand-cyan" />
                                </div>
                                <div>
                                  <div className="flex items-center gap-2 flex-wrap mb-0.5">
                                    <span className="text-[10px] font-bold uppercase tracking-wide text-brand-cyan/80">
                                      {c.category}
                                    </span>
                                    <span className="text-[10px] font-bold uppercase bg-brand-cyan/15 text-brand-cyan px-2 py-0.5 rounded-full">
                                      {c.badge}
                                    </span>
                                  </div>
                                  <p className="font-bold text-white">
                                    {c.title}
                                  </p>
                                </div>
                              </div>
                              <ChevronDown
                                size={18}
                                className={`text-white/40 transition-transform shrink-0 ${isOpen ? "rotate-180" : ""}`}
                              />
                            </button>
                            <AnimatePresence>
                              {isOpen && (
                                <motion.div
                                  initial={{ height: 0, opacity: 0 }}
                                  animate={{ height: "auto", opacity: 1 }}
                                  exit={{ height: 0, opacity: 0 }}
                                  transition={{ duration: 0.25 }}
                                  className="overflow-hidden"
                                >
                                  <div className="px-5 pb-5 pt-0">
                                    <p className="text-sm text-white/60 leading-relaxed mb-4">
                                      {c.detail}
                                    </p>
                                    <div className="flex flex-wrap gap-2 mb-4">
                                      {c.tags.map((t) => (
                                        <span
                                          key={t}
                                          className="text-[11px] text-white/70 bg-white/10 rounded-full px-3 py-1"
                                        >
                                          {t}
                                        </span>
                                      ))}
                                    </div>
                                    <div className="flex items-center justify-between">
                                      <span className="text-xs text-white/40">
                                        {c.duration}
                                      </span>
                                      <button
                                        type="button"
                                        onClick={() =>
                                          openAdmissionForm(c.title)
                                        }
                                        className="inline-block rounded-full bg-brand-cyan text-[#050b16] text-xs font-bold px-5 py-2"
                                      >
                                        Apply Online →
                                      </button>
                                    </div>
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Simple 4-step journey */}
                  <div>
                    <h3 className="text-xl font-bold text-white mb-6">
                      Simple 4-Step Journey
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      {journeySteps.map((s, i) => (
                        <div
                          key={s.title}
                          className="rounded-2xl border border-white/10 bg-white/5 p-5"
                        >
                          <div className="text-brand-cyan font-bold text-sm mb-2">
                            {String(i + 1).padStart(2, "0")}
                          </div>
                          <p className="font-bold text-white mb-1">{s.title}</p>
                          <p className="text-xs text-white/50">{s.desc}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Key program highlights */}
                  <div id="highlights">
                    <h3 className="text-xl font-bold text-white mb-6">
                      Key Program Highlights
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {highlights.map((h) => (
                        <div
                          key={h}
                          className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 px-5 py-4 text-sm text-white/80"
                        >
                          <span className="w-2 h-2 rounded-full bg-brand-cyan shrink-0" />
                          {h}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {active === "internship" && (
                <div className="space-y-10">
                  <div>
                    <h2
                      className="text-2xl md:text-3xl font-bold text-white mb-4"
                      style={{ fontFamily: "var(--font-poppins)" }}
                    >
                      Real-World Internships
                    </h2>
                    <p className="text-white/60 max-w-2xl leading-relaxed">
                      Gain hands-on industry experience through internship
                      placements with our partner companies across IT, banking,
                      and healthcare sectors.
                    </p>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white mb-4">
                      Your Internship Deliverables
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {internshipDeliverables.map((d) => (
                        <div
                          key={d}
                          className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 px-5 py-4 text-sm text-white/80"
                        >
                          <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                          {d}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
                    <p className="text-white font-bold mb-1">
                      Program Overview: Learn, Build, and Get Placed!
                    </p>
                    <p className="text-sm text-white/50">
                      Every internship pairs structured learning with a real
                      deliverable — so you leave with proof of work, not just a
                      certificate.
                    </p>
                  </div>
                </div>
              )}

              {active === "admission" && (
                <div className="space-y-10">
                  <div>
                    <h2
                      className="text-2xl md:text-3xl font-bold text-white mb-4"
                      style={{ fontFamily: "var(--font-poppins)" }}
                    >
                      Simple, Transparent Admissions
                    </h2>
                    <p className="text-white/60 max-w-2xl leading-relaxed">
                      A streamlined, fully digital admission process — from
                      application to enrollment — with dedicated counselor
                      support at every step.
                    </p>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white mb-6">
                      How It Works
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      {admissionSteps.map((s, i) => (
                        <div
                          key={s.title}
                          className="rounded-2xl border border-white/10 bg-white/5 p-5"
                        >
                          <div className="text-brand-cyan font-bold text-sm mb-2">
                            Step {i + 1}
                          </div>
                          <p className="font-bold text-white mb-1">{s.title}</p>
                          <p className="text-xs text-white/50">{s.desc}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-4">
                    <button
                      type="button"
                      onClick={() => openAdmissionForm()}
                      className="rounded-full bg-brand-cyan text-[#050b16] text-sm font-bold px-7 py-3"
                    >
                      Student Admission
                    </button>
                    <a
                      href="https://api.whatsapp.com/send/?phone=9219572223&text&type=phone_number&app_absent=0"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="rounded-full border border-white/20 text-white text-sm font-semibold px-7 py-3 hover:bg-white/10"
                    >
                      WhatsApp Support
                    </a>
                  </div>

                  {showForm && (
                    <div id="admission-form" className="scroll-mt-40">
                      <div className="flex items-center justify-between mb-6">
                        <h3
                          className="text-xl md:text-2xl font-bold text-white"
                          style={{ fontFamily: "var(--font-poppins)" }}
                        >
                          Student Admission
                        </h3>
                        <button
                          type="button"
                          onClick={() => setShowForm(false)}
                          className="text-sm text-white/60 hover:text-white"
                        >
                          Close ✕
                        </button>
                      </div>
                      <ApplicationForm
                        kind="admission"
                        initialProgram={formCourse}
                        key={formCourse ?? "none"}
                      />
                    </div>
                  )}
                </div>
              )}

              {active === "partners" && (
                <div className="space-y-8">
                  <div>
                    <h2
                      className="text-2xl md:text-3xl font-bold text-white mb-4"
                      style={{ fontFamily: "var(--font-poppins)" }}
                    >
                      50+ Leading University Partners
                    </h2>
                    <p className="text-white/60 max-w-2xl leading-relaxed">
                      Accredited university partners offering a wide range of
                      undergraduate, postgraduate, and diploma programs — UGC
                      and NAAC recognised.
                    </p>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    {Array.from({ length: 8 }).map((_, i) => (
                      <div
                        key={i}
                        className="aspect-video rounded-xl border border-white/10 bg-white/5 flex items-center justify-center text-white/20 text-xs"
                      >
                        University Logo
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {active === "events" && (
                <div className="space-y-8">
                  <div>
                    <h2
                      className="text-2xl md:text-3xl font-bold text-white mb-4"
                      style={{ fontFamily: "var(--font-poppins)" }}
                    >
                      Upcoming Events &amp; Educational Programs
                    </h2>
                    <p className="text-white/60 max-w-2xl leading-relaxed">
                      Regular webinars, career fairs, and skill-development
                      workshops designed to keep learners industry-ready.
                    </p>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {upcomingEvents.map((e) => (
                      <div
                        key={e.title}
                        className="rounded-2xl border border-white/10 bg-white/5 p-5"
                      >
                        <div
                          className="w-10 h-10 rounded-lg mb-4"
                          style={{ background: e.color }}
                        />
                        <p className="font-bold text-white mb-1">{e.title}</p>
                        <p className="text-xs text-white/40">{e.date}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </section>

        {/* Enroll CTA */}
        <section className="bg-gradient-to-r from-brand-cyan to-emerald-500 py-12 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-[#050b16] mb-2">
            Enroll with Full Support
          </h2>
          <p className="text-[#050b16]/70 mb-6">
            From application to placement — we&apos;re with you at every step.
          </p>
          <button
            type="button"
            onClick={() => openAdmissionForm()}
            className="inline-block rounded-full bg-[#050b16] text-white text-sm font-bold px-8 py-3 hover:bg-brand-navy transition-colors"
          >
            Register Now
          </button>
        </section>
      </main>
      <Footer />
      <FloatingButtons />
    </>
  );
}
